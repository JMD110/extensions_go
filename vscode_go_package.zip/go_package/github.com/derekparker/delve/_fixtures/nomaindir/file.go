package nomaindir

func AFunction() {
}
