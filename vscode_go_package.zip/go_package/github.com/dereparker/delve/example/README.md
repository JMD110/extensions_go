This directory contains a little program you can try debugging.

To debug:

    $ godebug run main.go
