/*
Command godebug provides debugging for Go packages.

Example Usage

Generate debugging code for the package in the current directory:

	$ godebug -w .
*/
package main
