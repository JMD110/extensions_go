// The start of an eval() function for go.

// The main entry point is:
//  func EvalExpr(expr ast.Expr, env Env)
//    (*[]reflect.Value, bool, error)

package eval
